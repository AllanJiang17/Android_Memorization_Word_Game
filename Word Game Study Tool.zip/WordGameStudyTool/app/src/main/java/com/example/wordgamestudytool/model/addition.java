package com.example.wordgamestudytool.model;

import java.util.HashMap;

public class addition {
    private HashMap<String, String> questionAnswer;

    public addition() {
        questionAnswer = new HashMap<>();
    }

    public void set(String question, String answer){
        questionAnswer.put(question, answer);
    }

    public HashMap get(){
        return questionAnswer;
    }
}
